# Machine-Learning-382-Project2-Group_J
Predicting whether a customer will churn from past behavior and demographics
